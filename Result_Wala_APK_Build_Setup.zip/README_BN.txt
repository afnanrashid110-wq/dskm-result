RESULT WALA APK BUILD SETUP

Repository: https://github.com/afnanrashid110-wq/dskm-result

1) Extract this ZIP.
2) In GitHub open the repository, choose Add file > Upload files.
3) Upload package.json, capacitor.config.json, and manifest.json to the repository root.
4) Also upload android-apk.yml into the exact path .github/workflows/android-apk.yml.
   If the mobile upload screen cannot upload hidden folders, create the folders in GitHub using Add file > Create new file and enter the path .github/workflows/android-apk.yml, then paste the workflow content.
5) Do NOT replace or delete index.html.
6) Commit the changes.
7) Open the Actions tab and run "Build Result Wala Android APK" (or wait for the push-triggered run).
8) When successful, open the workflow run, download the Result-Wala-Android-APK artifact ZIP, extract it, and find app-debug.apk.

Notes:
- This adds build automation; it does not itself publish an APK until files are committed and the workflow succeeds.
- The APK is a test/debug build, not a Play Store signed release.
- The app bundles the current index.html. Rebuild the APK after later website changes.
- First build may use the default Capacitor launcher icon; custom icon can be added later.
